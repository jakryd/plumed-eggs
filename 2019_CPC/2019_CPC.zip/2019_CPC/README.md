__J. Rydzewski__  
*maze: Heterogeneous Ligand Unbinding along Transient Protein Tunnels*  
Submitted (2019)  
[arXiv](https://arxiv.org/abs/1904.03929)  
[Github](https://github.com/maze-code/plumed2-maze)
