__J. Rydzewski__, and O. Valsson  
*Finding Multiple Reaction Pathways of Ligand Unbinding*  
J. Chem. Phys. 150, 221101 (2019)  
[DOI](https://doi.org/10.1063/1.5108638)  
[arXiv](https://arxiv.org/abs/1808.08089)  
[Github](https://github.com/maze-code/plumed2-maze)
