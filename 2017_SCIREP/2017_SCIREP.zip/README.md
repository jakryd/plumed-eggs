**J. Rydzewski**, and W. Nowak  
Thermodynamics of Camphor Migration in Cytochrome P450cam by Atomistic Simulations  
Sci. Rep. 7, 7736 (2017)  
[DOI](https://doi.org/10.1038/s41598-017-07993-0)
