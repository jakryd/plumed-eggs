__J. Rydzewski__, R. Jakubowski, W. Nowak, and H. Grubmüller  
*Kinetics of Huperzine A Dissociation from Acetylcholinesterase via Multiple Unbinding Pathways*  
J. Chem. Theory Comput. 14, 2843 (2018)  
[DOI](https://doi.org/10.1021/acs.jctc.8b00173)
