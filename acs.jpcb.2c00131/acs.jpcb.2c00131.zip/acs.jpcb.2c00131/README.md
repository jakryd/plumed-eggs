__J. Rydzewski__, K. Walczewska-Szewc, S. Czach, W. Nowak, K. Kuczera
*Enhancing the Inhomogeneous Photodynamics of Canonical Bacteriophytochrome*
J. Phys. Chem. B (2022)  
[DOI](https://doi.org/10.1021/acs.jpcb.2c00131)  
[ChemRxiv](https://doi.org/10.26434/chemrxiv-2021-n8hlc-v3)  
